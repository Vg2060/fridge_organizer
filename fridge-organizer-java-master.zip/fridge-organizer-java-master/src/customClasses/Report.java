package customClasses;

public class Report {

}
