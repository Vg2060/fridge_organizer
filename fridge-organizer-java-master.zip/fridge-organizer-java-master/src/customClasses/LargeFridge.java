package customClasses;

public class LargeFridge extends Fridge {

	public LargeFridge(int id, String fridgeName,int cap) {
		super(id, fridgeName, cap);
		// TODO Auto-generated constructor stub
	}

}
