package customClasses;


public class SmallFridge extends Fridge{

	public SmallFridge(int id, String fridgeName, int cap) {
		super(id, fridgeName, cap);
		// TODO Auto-generated constructor stub
	}
	
	
}
